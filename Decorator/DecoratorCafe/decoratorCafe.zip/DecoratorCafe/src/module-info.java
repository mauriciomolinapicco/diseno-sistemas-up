/**
 * 
 */
/**
 * 
 */
module DecoratorCafe {
}