package DecoratorCafe;

public class TostadoIntenso implements Cafe {

	@Override
	public int precio() {
		return 3500;
	}
}
