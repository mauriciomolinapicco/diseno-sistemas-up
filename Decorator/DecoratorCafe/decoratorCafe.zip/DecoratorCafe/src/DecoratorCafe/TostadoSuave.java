package DecoratorCafe;

public class TostadoSuave implements Cafe {

	@Override
	public int precio() {
		return 3000;
	}
	
}
