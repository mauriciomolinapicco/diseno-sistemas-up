package DecoratorCafe;

public interface Cafe {
	public int precio();
}
