package SubastaOnline;

public interface UsuarioInterface {
    void notificar(String notificacion);
}
