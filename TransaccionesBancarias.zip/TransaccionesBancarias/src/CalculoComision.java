public interface CalculoComision {
    //interface que define el metodo a ser implementado por las diferentes estrategias
    double calcularComision(double monto);
}
