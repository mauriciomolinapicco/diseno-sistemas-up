package CompositeArchivos;

public interface Entidad {
	String getNombre();
	int getTamanio();
}
